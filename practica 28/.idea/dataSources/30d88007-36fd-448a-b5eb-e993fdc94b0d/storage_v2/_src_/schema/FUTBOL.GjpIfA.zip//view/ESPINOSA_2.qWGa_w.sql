CREATE VIEW ESPINOSA_2 AS
  SELECT e.nombre, j.nombre, count(*)
  FROM jugadores j
  JOIN equipos e USING (id_equipo)
  JOIN goles USING (id_jugador)
GROUP BY e.nombre, j.nombre
/

