CREATE VIEW ALVARO_CLASIFICACION_FINAL AS
  SELECT nombre,NVL(partidos_ganados*3+partidos_empatados*1,0)
  as puntos,favor,contra,favor-contra as diferencia_goles,id_equipo
  FROM alvaro_ganados
FULL OUTER JOIN alvaro_empate USING (nombre)
FULL OUTER JOIN alvaro_goles_total USING (nombre)
join equipos USING (nombre)
/

