CREATE VIEW "MAÑOSO_PARTIDOS_GANADOS_TOTAL" AS
  select nombre,sum(partidos_ganados) partidos_ganados
from mañoso_partidos_ganados
group by nombre
/

