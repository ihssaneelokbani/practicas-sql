CREATE VIEW ALVARO_GOLES_TOTAL AS
  SELECT nombre,sum(favor)favor,sum(contra)contra
from alvaro_goles_partidos
GROUP BY nombre
/

