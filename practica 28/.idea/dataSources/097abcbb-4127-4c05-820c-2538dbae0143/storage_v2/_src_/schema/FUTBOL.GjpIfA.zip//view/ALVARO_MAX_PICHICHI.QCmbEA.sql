CREATE VIEW ALVARO_MAX_PICHICHI AS
  SELECT nombre,sum(casa+fuera) as total
  FROM alvaro_pichichi
GROUP BY nombre
/

