CREATE VIEW ALVARO_GOLES_PARTIDOS AS
  SELECT nombre,goles_casa as favor,goles_fuera as contra
  FROM equipos
JOIN partidos on (id_equipo=id_equipo_casa)
union all
SELECT nombre,goles_fuera as favor,goles_casa as contra
  FROM equipos
JOIN partidos on (id_equipo=id_equipo_fuera)
/

