CREATE VIEW ALVARO_EMPATE AS
  SELECT nombre,count(*) as partidos_empatados
from alvaro_goles_partidos
WHERE favor=contra
GROUP BY nombre
/

