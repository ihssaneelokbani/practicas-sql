CREATE VIEW ALVARO_GANADOS AS
  SELECT nombre,count(*) as partidos_ganados
from alvaro_goles_partidos
WHERE favor>contra
GROUP BY nombre
/

