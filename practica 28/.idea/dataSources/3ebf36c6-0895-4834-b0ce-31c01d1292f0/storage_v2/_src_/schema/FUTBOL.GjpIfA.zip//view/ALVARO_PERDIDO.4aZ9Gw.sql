CREATE VIEW ALVARO_PERDIDO AS
  SELECT nombre,favor,contra
from alvaro_goles_partidos
WHERE favor<contra
/

