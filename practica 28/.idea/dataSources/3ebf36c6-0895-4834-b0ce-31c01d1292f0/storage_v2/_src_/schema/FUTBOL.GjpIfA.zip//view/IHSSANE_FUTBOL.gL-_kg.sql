CREATE VIEW IHSSANE_FUTBOL AS
  select nombre,id_equipo_casa id_equipo, sum(goles_casa) as goles_favor,sum(goles_fuera)as goles_contra
 from equipos
 join partidos on(id_equipo=id_equipo_casa)
  group by nombre,id_equipo_casa
union all
  select nombre,id_equipo_fuera,sum(goles_fuera) as fueras,sum(goles_casa)as casasgo
  from equipos
   join partidos on(id_equipo=id_equipo_fuera)
  group by nombre,id_equipo_fuera
/

