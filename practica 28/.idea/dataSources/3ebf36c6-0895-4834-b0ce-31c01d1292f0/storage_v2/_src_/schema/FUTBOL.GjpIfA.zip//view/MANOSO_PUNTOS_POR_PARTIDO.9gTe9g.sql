CREATE VIEW "MAÑOSO_PUNTOS_POR_PARTIDO" AS
  SELECT nombre,
  decode(sign(goles_casa-goles_fuera),1,3,0,1,0) PUNTOS
from EQUIPOS
join partidos on(id_equipo=id_equipo_casa)
union all
    SELECT nombre,
  decode(sign(goles_fuera-goles_casa),1,3,0,1,0) PUNTOS
from EQUIPOS
join partidos on(id_equipo=id_equipo_fuera)
/

