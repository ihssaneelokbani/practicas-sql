CREATE VIEW ESPINOSA_1 AS
  SELECT nombre,sum(goles_casa),sum(goles_fuera)
  FROM equipos join partidos ON (id_equipo=id_equipo_casa)
GROUP BY nombre
UNION all
SELECT nombre,sum(goles_fuera),sum(goles_casa)
  FROM equipos join partidos ON (id_equipo=id_equipo_fuera)
GROUP BY nombre
/

