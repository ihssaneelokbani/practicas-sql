CREATE VIEW ALVARO_EQUIPO_MENOS_GOLES AS
  SELECT nombre,sum(favor) as total
from alvaro_goles_total
GROUP BY nombre
/

