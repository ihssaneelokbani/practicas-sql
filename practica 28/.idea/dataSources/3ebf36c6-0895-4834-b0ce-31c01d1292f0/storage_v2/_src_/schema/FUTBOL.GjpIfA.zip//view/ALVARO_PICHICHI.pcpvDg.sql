CREATE VIEW ALVARO_PICHICHI AS
  SELECT j.nombre,goles_casa as casa,goles_fuera as fuera
  from jugadores j
NATURAL JOIN goles
JOIN partidos USING (id_equipo_casa,id_equipo_fuera)
/

